/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import visao.FrmMenuPrincipal;

public class Principal {
    
    public static void main(String[] args) {
        
        FrmMenuPrincipal objetotela = new FrmMenuPrincipal();
        objetotela.setVisible(true);
    }
}
